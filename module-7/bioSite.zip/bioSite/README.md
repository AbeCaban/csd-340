<!DOCTYPE html>
<html lang="en-us">
    <body>
        <h1>CSD 340 Web Development with HTML and CSS</h1>
        <h2>Contributors</h2>
        <ul>
            <li>Sue</li>
            <li>Abraham Caban Rios</li>
        </ul>
    </body>

</html>